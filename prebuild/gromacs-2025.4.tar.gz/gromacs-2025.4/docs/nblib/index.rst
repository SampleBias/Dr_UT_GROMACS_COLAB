.. _nblib:

=================================
(Non-)Bonded LIBrary (NB-LIB) API
=================================

This documentation is part of the |Gromacs| `manual <http://manual.gromacs.org/current/>`_
and describes the (Non-)Bonded LIBrary (NB-LIB) API.

..  toctree::
    :maxdepth: 2

    guide-to-writing-MD-programs
