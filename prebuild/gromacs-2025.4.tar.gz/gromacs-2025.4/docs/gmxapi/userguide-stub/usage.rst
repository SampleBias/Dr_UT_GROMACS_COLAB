========================
Using the Python package
========================

.. seealso::

    This copy of the documentation was built without
    :doc:`installing the gmxapi package <../userguide/install>`,
    and therefore lacks the full module reference.
    Refer to :ref:`gmxapi_package_documentation` for instructions on building
    complete documentation, or `view online <http://manual.gromacs.org/current/gmxapi/>`__.
