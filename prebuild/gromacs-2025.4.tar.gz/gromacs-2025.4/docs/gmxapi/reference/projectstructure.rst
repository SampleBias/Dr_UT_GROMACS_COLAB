=======================
Implementation overview
=======================

stub
